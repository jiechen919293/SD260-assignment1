import React from 'react';
import './App.css';
import Movie from './components/Movie'
import Header from './components/Header'

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      results: [],
      inputValue: 'monster',
      favouriteMovies:[]
    }
  }
  getMovies = async (e) => {
    e.preventDefault()
    let key = this.state.inputValue
    const url = `https://api.themoviedb.org/3/search/movie?api_key=7b94aeb4b9c0dd930c28ea14fa3c1fcb&language=en-US&query=${key}&page=1`
    fetch(url)
      .then((result) => result.json())
      .then((result) => {
        if (result) {
          this.setState({ results: result.results });
          console.log(this.state.results);
        }
      })
  }
  handleChange = e => {
    this.setState({ inputValue: e.target.value })
  }
toggleFavourite=(movie)=>{
  const newFavouriteList = [...this.state.favouriteMovies, movie];
  this.setState({favouriteMovies:newFavouriteList});
}

  render() {
    return (<>
      <Header
        value={this.state.inputValue}
        handleSubmit={this.getMovies}
        handleChange={this.handleChange}
      />
      <div className="titleList">
        <div className="title">
          <h1>Movies</h1>
          <div className="titles-wrapper">
            {this.state.results.map((movie) => {
              return (<Movie movie={movie}
                handleClick={this.toggleFavourite}
                key={movie.id}
              />)
            })}
          </div>
        </div>
      </div>
    </>)

  }
}
export default App;