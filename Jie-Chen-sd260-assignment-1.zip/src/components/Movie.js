import React,{Component} from 'react';

class Movie extends Component {
    constructor(props){
        super(props);
        this.state={
            imgURL:"https://image.tmdb.org/t/p/w300",
           favouriteM:false
          };
    }
handleClick(){
    this.setState({favourite:!this.state.favouriteM})
}
render(){
  return (
      <div className="movie">
          <img src={(this.state.imgURL + this.props.movie.poster_path) ? (this.state.imgURL + this.props.movie.poster_path) :'./public/image-not-available.jpg'} alt='not-available' />
            <div className="overlay">
                <div className="title">{this.props.movie.title}</div>
                <div className="rating">{this.props.movie.vote_average}/10</div>
                <div className="plot">
                    {this.props.movie.overview}
                </div>
                <div data-toggled={this.state.favouriteM} 
                onClick={this.props.handleClick}
                 className="listToggle">
                    <div>
                        <i className="far fa-heart"></i><i className="fas fa-heart"></i>
                    </div>
                </div>
            </div>
        </div>    
    ) 
}



}

export default Movie